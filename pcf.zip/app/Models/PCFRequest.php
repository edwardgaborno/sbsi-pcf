<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Illuminate\Support\Facades\DB;

class PCFRequest extends Model implements HasMedia
{
    use HasFactory;
    use InteractsWithMedia;

    protected $guarded = [];

    public function path()
    {
        return url($this->getFirstMediaUrl('approved_pcf_rfq'));
    }

    public function pcfList() 
    {
        return $this->belongsTo(PCFList::class);
    }

    public function pcfInclusion() 
    {
        return $this->belongsTo(PCFInclusion::class);
    }

    public function pcfApprover() {
        return $this->hasMany(PCFApprover::class, 'p_c_f_request_id', 'id');
    }

    public function institution()
    {
        return $this->belongsTo(PCFInstitution::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function countDistinct($value)
    {
        $counts = DB::table('p_c_f_lists')
                ->select(DB::raw('COUNT(DISTINCT above_standard_price) AS totalDistinct'))
                ->where('p_c_f_request_id', $value)
                ->get();
        
        foreach($counts as $count) {
            return $count->totalDistinct;
        }   
    }

    public function checkColumnValue($value)
    {
        $data = PCFList::select('above_standard_price')->where('p_c_f_request_id', $value)->get();

        foreach($data as $datum) {
            return $datum->above_standard_price;
        }
    }
}
