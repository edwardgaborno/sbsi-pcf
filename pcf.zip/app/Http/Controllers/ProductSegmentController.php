<?php

namespace App\Http\Controllers;

use App\Models\ProductSegment;
use Illuminate\Http\Request;

class ProductSegmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ProductSegment  $productSegment
     * @return \Illuminate\Http\Response
     */
    public function show(ProductSegment $productSegment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ProductSegment  $productSegment
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductSegment $productSegment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ProductSegment  $productSegment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductSegment $productSegment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ProductSegment  $productSegment
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductSegment $productSegment)
    {
        //
    }
}
