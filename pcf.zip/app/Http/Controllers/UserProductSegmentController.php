<?php

namespace App\Http\Controllers;

use App\Models\UserProductSegment;
use Illuminate\Http\Request;

class UserProductSegmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\UserProductSegment  $userProductSegment
     * @return \Illuminate\Http\Response
     */
    public function show(UserProductSegment $userProductSegment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\UserProductSegment  $userProductSegment
     * @return \Illuminate\Http\Response
     */
    public function edit(UserProductSegment $userProductSegment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\UserProductSegment  $userProductSegment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserProductSegment $userProductSegment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\UserProductSegment  $userProductSegment
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserProductSegment $userProductSegment)
    {
        //
    }
}
