<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Scientific Biotech Specialties - Profitability Monitoring System</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->