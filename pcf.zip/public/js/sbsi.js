// $(function() {
//     $('input[name="birth_date"]').daterangepicker({
//         singleDatePicker: true,
//         showDropdowns: true
//     }, 
//     function(start, end, label) {
//         var years = moment().diff(start, 'years');
//         alert("You are " + years + " years old.");
//     });
// });


$(document).ready(function(){

    
});